﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    internal class Szyfrcezara : INotifyPropertyChanged
    {
        private bool czySzyfrowanie;
        private int klucz;
        private string tekst = string.Empty;
        private string wynik = string.Empty;


        public event PropertyChangedEventHandler? PropertyChanged;

        public void checkPropertyChangeEvent(string propertyName)
        {
            if(PropertyChanged != null) 
            {
            
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool CzySzyfrowanie
        {

            get { return czySzyfrowanie; }
            set
            {
                czySzyfrowanie = value;
                checkPropertyChangeEvent("CzySzyfrowanie");

            }
        }

        public string Tekst
        {
            get { return tekst; } 
            set 
            {
                tekst = value;
                checkPropertyChangeEvent("Tekst");
            }


        }

        public int Klucz
        {

            get { return klucz; }
            set
            {
                klucz = value;
                checkPropertyChangeEvent("Klucz");
            }


        }

        public string Wynik
        {
            get { return wynik; }
            set
            {
                wynik = value;
                checkPropertyChangeEvent("Wynik");
            }
        }



        public Szyfrcezara()
        {
            czySzyfrowanie = true;
            tekst = string.Empty;
            klucz = 0;
            wynik = string.Empty;

        }
        public void Szyfruj()
        {
            
            if(CzySzyfrowanie == true) {
                char[] alfabet = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
                Tekst = Tekst.ToUpper();
                char[] zdanie = Tekst.ToCharArray();

                char[] zaszyfrowane = new char[zdanie.Length];

                for (int i = 0; i < zdanie.Length; i++)
                {
                    char litera = zdanie[i];
                    if (zdanie[i] == ' ' || zdanie[i] == '\n') continue;
                    int pozycja = Array.IndexOf(alfabet, litera);
                    int nowaPozycja = (pozycja + Klucz) % 26;
                    char literaZaszyfrowana = alfabet[nowaPozycja];
                    zaszyfrowane[i] = literaZaszyfrowana;
                }

                Wynik = string.Join("", zaszyfrowane);
            }
            else if(CzySzyfrowanie == false)
            {
                char[] alfabet = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
                Tekst = Tekst.ToUpper();
                char[] zdanie = Tekst.ToCharArray();

                char[] zaszyfrowane = new char[zdanie.Length];

                for (int i = 0; i < zdanie.Length; i++)
                {
                    char litera = zdanie[i];
                    if (zdanie[i] == ' ' || zdanie[i] == '\n') continue;
                    int pozycja = Array.IndexOf(alfabet, litera);
                   if(Klucz == pozycja || Klucz > pozycja) { int nowaPozycja = 26 - (Klucz - pozycja);
                        char literaZaszyfrowana = alfabet[nowaPozycja];
                        zaszyfrowane[i] = literaZaszyfrowana;
                    }
                   else {
                        int nowaPozycja = (pozycja - Klucz) % 26;
                        char literaZaszyfrowana = alfabet[nowaPozycja];
                        zaszyfrowane[i] = literaZaszyfrowana;
                    }
                    
                }

                Wynik = string.Join("", zaszyfrowane);
            }
            
        }

    }
}
